#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void main() {
	int pid;
	int status;

	pid = fork();

	if (pid < 0) { // error occurred 
		fprintf(stderr, "Fork failed!\n");
		exit(-1);
	}else if (pid == 0) { // child process 
		sleep(10);
		printf("I am the child, return from fork=%d\n", pid);
		//execlp("/bin/ps", "ps", NULL);
		execlp("/bin/ls", "ls", NULL);
	}else { // parent process 
		sleep(2);
		printf("I am the parent, return from fork, child pid=%d\n", pid);
		printf("child pid = %d", wait(status));
		printf("Parent exiting!\n");
		//exit(0);
	}
}
