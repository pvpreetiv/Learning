#include <stdio.h>
#include <stdlib.h>



struct node {
	int data;
	struct node* next;
};

struct node* insert(int data) {
	struct node *new = (struct node*)malloc(sizeof(struct node));
	new->data = data;
	new->next = NULL;
	return new;
}

void traverse(struct node *head) {
	struct node* ptr = head;
	while(ptr!= NULL) {
		printf("%d \t", ptr->data);
		ptr = ptr->next;
	}
	printf("\n");
}

struct node* reverse(struct node *head) {
	struct node *tmp, *curr, *pre;
	pre = NULL;
	curr = head;
	while(curr != NULL) {
		tmp = curr->next;
		curr->next = pre;
		pre = curr;
		curr = tmp;
	}
	return pre;
}


void main() {
	struct node *head = NULL, *ptr = NULL, *tmp = NULL;
	char ch;
	int data;

//	printf("enter nodes(y/n)");
//	scanf("%c", &ch);
//	while(ch == 'y') {
//		scanf("%d", &data);
	for(data = 0; data < 5; data++)
		if(head == NULL) {
			head = insert(data);
			ptr = head;
		}
		else {
			tmp = insert(data);
			ptr->next = tmp;
			ptr = tmp;
		}
//		getchar();
//		printf("enter ur choice (y/n)");
//		scanf("%c", &ch);
//	}
	
	traverse(head);
	head = reverse(head);
	traverse(head);
	

}
