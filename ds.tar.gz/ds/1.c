#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node {
	char data;
	struct node *ptr;
} *top;


void push(char data) {
	struct node *new = NULL;
	if(top == NULL) {
		new = (struct node*)malloc(sizeof(struct node));
		new->data = data;
		new->ptr = NULL;
		top = new;
	}
	new = (struct node*)malloc(sizeof(struct node));
	new->data = data;
	new->ptr = top;
	top = new;
}

char pop() {
	struct node* tmp;
	char data;
	tmp = top;

	if(top == NULL)
		return -1;
	top = top->ptr;
	data = tmp->data;
	free(tmp);

	return data;	
}

int isMatching(char c1, char c2) {

	printf("chars recvd : %c %c \n", c1, c2);
	if(c1 == '(' && c2 == ')')
		return 1;
        if(c1 == '{' && c2 == '}')
                return 1;
        if(c1 == '[' && c2 == ']')
                return 1;
	return 0;
}

void main() {
	char *s = "{{(}([])}";
	int i = 0;
	char tmp;
	struct node *top = NULL;

	for (i = 0; i < strlen(s); i++) {
		if(s[i] == '(' || s[i] == '{' || s[i] == '[')
			push(s[i]);
		if(s[i] == ')' || s[i] == '}' || s[i] == ']') {
			tmp = pop();
			if(! isMatching(tmp, s[i])){
				printf("not  matched\n");
				break;
			}				
		}			
	}

	if(i == strlen(s))
		printf("matched\n");

}
