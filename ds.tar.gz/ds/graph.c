#include <cstdio>
#include <cstdlib>
#include <list>
#include <iostream>

using namespace std;

struct adjListNode {
	int data;
	struct adjListNode *next;
};

struct adjList {
	struct adjListNode *head;
};

struct graph {
	int V;
	struct adjList *arr;
};

struct adjListNode* createNode(int v) {
	struct adjListNode *newNode = (struct adjListNode*)malloc(sizeof(struct adjListNode));
	newNode->data = v;
	newNode->next= NULL;
	return newNode;
}

void insert(struct graph *mygraph, int v, int e) {
	struct adjListNode *newNode;
	if(mygraph->arr[v].head == NULL) {
		mygraph->arr[v].head = createNode(e);
 	}
	else {
		newNode = createNode(e);
		newNode->next = mygraph->arr[v].head;
		mygraph->arr[v].head = newNode;
	}
}

void BFStraversal(struct graph *mygraph) {
	list<int> Q;
	int i;
	int start = 0;
	struct adjListNode *tempNode = NULL;
	
	/*bool array to mark visited or not*/
	bool *visited = new bool(mygraph->V);
	for(i=0; i< mygraph->V; i++)
		visited[i] = false;

	Q.push_back(start);
	visited[start] = true;

	while(!Q.empty()) {
		start = Q.front();
		cout << start << " ";
		Q.pop_front();
		tempNode = mygraph->arr[start].head;
		while(tempNode != NULL) {
			if(!visited[tempNode->data]) {
				visited[tempNode->data] = true;
				Q.push_back(tempNode->data);
			}
			tempNode =tempNode->next;
		}
		
	}
}

void DFStraversal(struct graph *mygraph) {

}

void printGraph(struct graph *mygraph) {
	int i;
	struct adjListNode *tempNode;
	for(i = 0; i< mygraph->V; i++) {
		tempNode = mygraph->arr[i].head;
		printf("\ni: %d ", i);
		while(tempNode != NULL) {
			printf(" %d ", tempNode->data);
			tempNode =tempNode->next;
		}
	}
}


int main() {
	int i = 0;
	struct graph *mygraph = (struct graph*)malloc(sizeof(struct graph));
	mygraph->V=5;
	mygraph->arr = (struct adjList*)malloc(mygraph->V*sizeof(struct adjList));
	for(i=0; i<mygraph->V; i++)
		mygraph->arr[i].head = NULL;

	insert(mygraph, 0, 1);
	insert(mygraph, 0, 4);
	insert(mygraph, 1, 2);
	insert(mygraph, 1, 3);
	insert(mygraph, 1, 4);
	insert(mygraph, 2, 3);
	insert(mygraph, 3, 4);

	printf("\n#########print graph#######\n");
	printGraph(mygraph);

	printf("\n#########BFS traversal#######\n");
	BFStraversal(mygraph);
	return 0;
}

