#include <stdio.h>

int binarySearch(int arr[], int size, int x) {
	int l = 0, r = size, mid;

	while(l < r) {
		mid = (l+r-1)/2;
		if(arr[mid] == x) return mid;
		
		if(arr[mid] < x) l = mid+1;
		else 	r= mid-1;
	}

	return -1;	
}
void main() {
	int arr[4][4] = {{0,1,1,1},
			{0,0,1,1},
			{1,1,1,1},
			{0,0,0,0}};
	int max = 0, i, curr, idx, r = 4;

	for(i=0; i<r; i++) {
		curr = binarySearch(arr[i], 4, 1);
		printf("%d ith row contains %d 1's\n", i, r-curr);
		if(curr >max)
			idx = i;
	}
	
	printf("row with max 1's : %d \n", idx);
}
