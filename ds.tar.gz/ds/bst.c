#include <stdio.h>
#include <malloc.h>

struct node {
	int data;
	struct node *left;
	struct node *right;
	
};

struct node* createNode(int data)
{
	struct node* new;
	new = (struct node*)malloc(sizeof(struct node*));
	new->data = data;
	new->left = NULL;
	new->right = NULL;
}

void preorder_traverse(struct node* root) {
	/*preorder traversal*/
        if(root == NULL)
                return;
        printf("%d ", root->data);
        if(root->left != NULL)
                preorder_traverse(root->left);
        if(root->right != NULL)
                preorder_traverse(root->right);	
}

void inorder_traverse(struct node* root) {
	/*inorder traversal*/
        if(root != NULL) {
                inorder_traverse(root->left);
	        printf("%d ", root->data);
                inorder_traverse(root->right);
	}
}

void insert(struct node* root, int data) {
	
	if(root == NULL) {
		struct node *new = createNode(data);
		
	}
	/*left tree*/
	if(data < root->data && root->left == NULL) {
		struct node *new = createNode(data);
		new->data = data;
		new->left = NULL;
		new->right = NULL;
		root->left = new;
	}
	/*Right tree*/
        else if(data > root->data && root->right == NULL) {
                struct node *new = createNode(data);
                new->data = data;
                new->left = NULL;
                new->right = NULL;
                root->right = new;
        }
	else if(data < root->data)
		insert(root->left, data);
	else
		insert(root->right, data);
	
}

void delete(struct node* root, int data) {
	if(root == NULL)
		return;
	if(root->left == NULL && root->right == NULL) {
		free(root);
		printf("node deleted");
	}
}

void main() {
	int data = 50;
	struct node *root = (struct node*)malloc(sizeof(struct node*));
        root->data = data;
        root->left = NULL;
        root->right = NULL;
	insert(root, 30);
	insert(root, 70);
	insert(root, 80);
	insert(root, 20);
	insert(root, 40);
	insert(root, 60);

	printf( "\npreorder traversal : ");
	preorder_traverse(root);
	printf("\n inorder traversal : ");
	inorder_traverse(root);
}
