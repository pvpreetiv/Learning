#include "headers_cpp.h"


class stack{
private:
	int data;
	int *top;
public:
	void push(int data);
	void pop(int data);
	void traverse();
};

void stack::push(int data) {
	
}

void main() {
	
}
