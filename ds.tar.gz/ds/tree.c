#include <stdio.h>
#include <malloc.h>

struct node {
	int data;
	struct node *left;
	struct node *right;
};

struct node* create(int data)
{
	struct node *new = (struct node*)malloc(sizeof(struct node));
	new->data = data;
	new->left = NULL;
	new->right = NULL;

	return new;
	
}

void traverse(struct node *root)
{
	if(root == NULL)
		return;
	printf("%d ", root->data);
	if(root->left != NULL)
		traverse(root->left);
	if(root->right != NULL)
                traverse(root->right);
}

int height(struct node *root)
{
        if(root == NULL)
		return 0;
	return max(height(root->left), height(root->right))+ 1;
}

void main()
{
	/*Create tree*/
	struct node *root;
	root = create(1);
	root->left = create(2);
	root->right = create(3);
	root->left->left = create(4);
	root->left->right = create(5);
	root->left->right->right = create(6);
	

	traverse(root);
	printf("height of tree: %d\n", height(root));
	
}
