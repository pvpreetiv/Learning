
usage() {
	echo ""
	echo "1. GwDevcontrol"
	echo "2. eCMMaster"
	echo "3. PCPD"
	echo "4. NVM"
	echo "5. Cable Modem Firmware"
	echo "6. Infra_init script"
	echo "enter choice"
}

main() {

loop=1;

while [ $loop -eq 1 ]
do
	usage

	read input

	case "$input" in
	1)
		make .clean_bcn_gwdevcontrol;
		make bcn_gwdevcontrol;
		make .install_bcn_gwdevcontrol;
	;;

	2)
        	make .clean_bcn_ecmmaster;
	        make bcn_ecmmaster;
        	make .install_bcn_ecmmaster;
	;;

	3)
        	make .clean_bcn_pcpd;
	        make bcn_pcpd;
        	make .install_bcn_pcpd;
	;;

	4)
		make .clean_nvmdb;
		make nvmdb;
		make .install_nvmdb;
	;;
	
	5)
		make .clean_cable_modem_firmwares_int;
		make .install_cable_modem_firmwares_int;
	;;

	6)
		make .clean_infracomms;
		make .install_infracomms;
	;;

	*)
		echo "wrong input"

		echo ""
		echo ""
		echo "valid choices are 1/2/3/4/5"
		usage
		loop=0;
	;;
esac

done
}

main "$@"
