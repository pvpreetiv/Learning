/opt/STM/STLinux-2.4/host/stmc/bin/stmcconfig --ip 10.199.$1 --serial-relay
telnet 10.199.$1 5331
