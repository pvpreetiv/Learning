ifconfig fpgige0 hw ether 9e:25:06:97:38:99
ifconfig fpgige0 192.168.1.1 netmask 255.255.255.0 up
iptables -t nat -F
iptables -t nat -A POSTROUTING -s 192.168.1.100 -d 192.168.100.0/24  -j SNAT --to 192.168.100.29
sysctl -w net.ipv4.ip_forward=1
#modprobe stlinuxtv
