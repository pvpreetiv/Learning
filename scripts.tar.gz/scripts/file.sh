
#if [ -f "/root/nvmdb/flash.bin" ] && [ -f "/root/nvmdb/cable_modem_1.elf" ] && [ -f "/root/nvmdb/cable_modem_2.elf" ]
FLASH_BIN=/root/nvmdb/flash.bin
CABLE_MODEM_1=/root/nvmdb/cable_modem_1.elf
CABLE_MODEM_2=/root/nvmdb/cable_modem_2.elf

function COLORED_ECHO() {
	echo -e "\033[31mFile $1 not found.\e[0m"
}

if [ ! -f ${FLASH_BIN} ]
then
	COLORED_ECHO ${FLASH_BIN}
else
	if [ ! -f ${CABLE_MODEM_1} ]
	then
		COLORED_ECHO ${CABLE_MODEM_1}
	elif [ ! -f ${CABLE_MODEM_2} ]
	then
		COLORED_ECHO ${CABLE_MODEM_2}
	fi
fi
