ifconfig eth0 hw ether 9e:25:06:97:58:74
ifconfig eth0 192.168.1.100 netmask 255.255.255.0 up
route add -net 192.168.100.0 netmask 255.255.255.0 gw 192.168.1.1
