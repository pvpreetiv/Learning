/*Constructor - destructor*/

#include <iostream>

using namespace std;

class shape {
	public:
	shape() { cout << "shape constructor" << endl; }
	~shape() { cout << "shape destructor" << endl; }
	virtual int getarea() { }
};


class square : public shape {
	public:
	square() { cout << "square constructor" << endl; }
	~square() { cout << "square destructor" << endl; }
	int getarea();
};

int square:: getarea() {  return 5*5;}

#if 0
class cube : public shape {
	public:
	cube() { cout << "cube constructor"; }
	int getarea() { a= 5; return 6*a*a; }
};

class circle : public shape {
        public:
	circle() { cout << "circle constructor"; }
	int getarea() { a= 5; return (22/7)*a*a; }
};

#endif
int main() {
	shape *s = new square;

	cout << " area = " << s->getarea();

	delete s;
	shape s1;
	cout << "area = base class " << s1.getarea();
	
}
